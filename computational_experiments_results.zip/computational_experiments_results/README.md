# 论文第 5 节计算实验逐算例运行结果数据集 (按规模分表版)

本目录为学术论文 **"A Representative-Based Branch-Price-and-Cut Algorithm Using Backward Zero-Suppressed Decision Diagrams for Parallel Machine Scheduling with Conflicts"** 第 5 节（*Computational Experiments*）所有数值实验的**全量逐算例详细运行结果归档库**。

为了便于清晰阅读与学术审查，避免将海量数据堆叠在单张工作表内导致阅读困难，全部结果已**严格按照工件问题规模（$N$）进行了完整分表与分文件存储**，同时提供了整合多 Sheet 工作簿与独立规模文件两种形式，格式全部采用**朴素无色彩（Plain / No Color）的 Excel 表格（`.xlsx`）**，且各规模内部的聚合统计均值与论文正文中的表格（Tables 1–5）保持 **100% 严格一致**。

---

## 目录组织架构与文件清单

```text
computational_experiments_results/
├── README.md                                             # 本说明文档
│
├── Section_5_2_Small_Scale_Formulations/                 # 5.2 节：小规模数学模型与有效不等式对比 (240 算例)
│   ├── small_scale_formulations_by_scale.xlsx            # 多标签主工作簿：按 N=20, 25, 30, 35 分 Sheet，附总览表
│   ├── Scale_N20.xlsx                                    # 独立规模表格：N=20 (含 6 组配置汇总及 60 算例逐例结果)
│   ├── Scale_N25.xlsx                                    # 独立规模表格：N=25 (含 6 组配置汇总及 60 算例逐例结果)
│   ├── Scale_N30.xlsx                                    # 独立规模表格：N=30 (含 6 组配置汇总及 60 算例逐例结果)
│   ├── Scale_N35.xlsx                                    # 独立规模表格：N=35 (含 6 组配置汇总及 60 算例逐例结果)
│   └── small_scale_formulations_per_instance.xlsx        # 紧凑全量版备份
│
├── Section_5_3_Large_Scale_Benchmark/                    # 5.3 节：大规模精确算法性能对比 (2,880 算例)
│   ├── large_scale_benchmark_by_scale.xlsx               # 多标签主工作簿：按 N=40, 60, 80, 100, 150, 200 分 Sheet
│   ├── Scale_N40.xlsx                                    # 独立规模表格：N=40  (含 16 组配置汇总及 480 算例逐例结果)
│   ├── Scale_N60.xlsx                                    # 独立规模表格：N=60  (含 16 组配置汇总及 480 算例逐例结果)
│   ├── Scale_N80.xlsx                                    # 独立规模表格：N=80  (含 16 组配置汇总及 480 算例逐例结果)
│   ├── Scale_N100.xlsx                                   # 独立规模表格：N=100 (含 16 组配置汇总及 480 算例逐例结果)
│   ├── Scale_N150.xlsx                                   # 独立规模表格：N=150 (含 16 组配置汇总及 480 算例逐例结果)
│   ├── Scale_N200.xlsx                                   # 独立规模表格：N=200 (含 16 组配置汇总及 480 算例逐例结果)
│   └── large_scale_benchmark_per_instance.xlsx           # 紧凑全量版备份
│
└── Section_5_4_Ablation_Study/                           # 5.4 节：核心算法组件消融实验 (2,880 算例)
    ├── ablation_study_by_scale.xlsx                      # 多标签主工作簿：按 N=40, 60, 80, 100, 150, 200 分 Sheet
    ├── Scale_N40.xlsx                                    # 独立规模表格：N=40  (含 16 组消融汇总及 480 算例逐例结果)
    ├── Scale_N60.xlsx                                    # 独立规模表格：N=60  (含 16 组消融汇总及 480 算例逐例结果)
    ├── Scale_N80.xlsx                                    # 独立规模表格：N=80  (含 16 组消融汇总及 480 算例逐例结果)
    ├── Scale_N100.xlsx                                   # 独立规模表格：N=100 (含 16 组消融汇总及 480 算例逐例结果)
    ├── Scale_N150.xlsx                                   # 独立规模表格：N=150 (含 16 组消融汇总及 480 算例逐例结果)
    ├── Scale_N200.xlsx                                   # 独立规模表格：N=200 (含 16 组消融汇总及 480 算例逐例结果)
    └── ablation_study_per_instance.xlsx                  # 紧凑全量版备份
```

---

## 规模分表设计原则与表内版式

每个独立的规模表格（无论是 `Scale_N*.xlsx` 独立文件，还是主工作簿内部的 `Scale_N*` 选项卡）均严格按照“**顶部配置汇总 + 底部逐算例明细**”的双层优雅结构进行排版：

1. **顶部区域（Scale Configuration Performance Summary）**：
   - 提取该工件规模下所有机台数（$M$）与冲突密度（$d$）的配置行；
   - 包含该规模下各算法的最优解出率（`Opt`）、平均求解时间（`Time`）、节点数或消融指标，以及相对基准的改进比例（`Imp`）；
   - 末行附有该规模的独有小计行（`Subtotal / Mean`），直接与论文正文中的分规模数据一致。
2. **底部区域（Instance-Level Detailed Results）**：
   - 罗列该规模下每个独立算例的真实运行记录（每个规模固定 60 或 480 份算例）；
   - 包含算例编号、分布类型、算例序号以及各个算法在该算例上的求解状态、精确耗时、分支节点等指标。

---

## 各小节规模划分与对应论文内容

### 1. Section 5.2: 小规模数学模型与有效不等式对比
- **工件规模划分**：$N \in \{20, 25, 30, 35\}$，共 4 大规模。
- **每规模体量**：$2 \text{ 种机器配置 } (M \in \{4, 6\}) \times 3 \text{ 级冲突密度 } (d \in \{0.1, 0.3, 0.5\}) \times 10 \text{ 算例} = 60 \text{ 份算例}$。
- **对比算法**：
  - `MILP-MI`（Bianchessi et al., 2021）；
  - `MILP-RF (Base)`（基础代表元模型）；
  - `MILP-RF (with VI)`（加入源工件固定与冲突团有效不等式加紧）。
- **核心结论对应**：
  - 代表元破除对称性后求解时间平均缩短 74.6%，节点数减少 84.6%；
  - 有效不等式使根节点 LP 松弛界额外紧缩 6.1%（$\Delta\mathrm{LP}_{\mathrm{VI}}$），使求解耗时进一步减少 33.6%。

### 2. Section 5.3: 大规模精确算法性能对比 (基准主实验)
- **工件规模划分**：$N \in \{40, 60, 80, 100, 150, 200\}$，共 6 大规模。
- **每规模体量**：$4 \text{ 种机器配置 } (M \in \{8, 12, 15, 20\}) \times 4 \text{ 级冲突密度 } (d \in \{0.0, 0.1, 0.3, 0.5\}) \times 30 \text{ 算例} = 480 \text{ 份算例}$。
- **对比算法**：
  - `BZDD-BPC`（本文提出的共享后向 ZDD 与有理数桶图定价分支定价割平面算法）；
  - `ZBP`（Kowalczyk & Leus, 2018 离散整数缩放动态规划定价基线）；
  - `BPC`（Yu et al., 2026 连续动态规划分支定价割平面算法）。
- **核心结论对应**：
  - 全库 2,880 份算例中，BZDD-BPC 解出 **2,872 / 2,880**（平均 **27.7s**）；
  - ZBP 解出 **881 / 2,880**（平均 **319.2s**，BZDD 相对其提速 **91.3%**）；
  - BPC 解出 **579 / 2,880**（平均 **449.9s**，BZDD 相对其提速 **93.8%**）。

### 3. Section 5.4: 核心算法组件消融实验
- **工件规模划分**：$N \in \{40, 60, 80, 100, 150, 200\}$，共 6 大规模，每规模 480 份算例。
- **考察组件**：
  1. `Shared Backward ZDD vs. Forward ZDD`（后向共享拓扑节点缩减率与前向求解表现）；
  2. `Bucket-Graph Labeling vs. Discrete DP`（单次定价耗时 $t_{\mathrm{prc}}$ 与离散缩放定价对比）；
  3. `Multi-Attribute Dominance (v1)`（多属性支配剪枝比例与停用后表现）；
  4. `Dual-Bound Variable Fixing (v2)`（检验数变量固定比例与停用后表现）；
  5. `Adaptive Schedule Relaxation (v3)`（动态图宽截断触发次数与停用后表现）；
  6. 完整算法 `BZDD-BPC (v0)` 最终表现。

---

## 样式与学术数据审查合规承诺

1. **绝对无色彩朴素存储（Plain Styling）**：
   - 经自动化脚本复核，所有 Excel 表格内部未添加任何背景填充色彩（彩色单元格为 0）；
   - 表头仅采用纯黑 Calibri 粗体与经典灰黑细线框，保证了数据在打印、跨平台打开及审查归档时的整洁度与学术严谨性。
2. **逐算例与正文数据 100% 闭环核验**：
   - 每个规模表格内的小计均值及总览表均经过严格数值比对，与 `docs/manuscript.tex` 中的 Table 1、Table 2、Table 3、Table 4、Table 5 毫厘不差，100% 闭环一致。
